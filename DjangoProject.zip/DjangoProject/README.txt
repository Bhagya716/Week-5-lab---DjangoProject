--> First install Django application.

--> Create DjangoProject by using the following command 
    django-admin startproject DjangoProject

--> Once django project created then create HelloWorld App using the following command
    django-admin startapp HelloworldDjango_App

--> Make some changes in the following files in Django project folder
    setting.py, urls.py, views.py, urls.py

--> URL will be obtained through running server. 

--> Now access the URL, you will get the output through browser. 